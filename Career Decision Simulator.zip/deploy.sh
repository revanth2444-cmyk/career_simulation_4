#!/bin/bash

# 🚀 Quick Deploy Script for Career Decision Simulator

echo "🎯 Reality Forking: Career Decision Simulator"
echo "=============================================="
echo ""

# Check if git is initialized
if [ ! -d .git ]; then
    echo "📦 Initializing Git repository..."
    git init
    git add .
    git commit -m "Initial commit: Career Decision Simulator"
fi

echo ""
echo "Choose your deployment platform:"
echo "1) Vercel (Recommended - Fastest)"
echo "2) Netlify"
echo "3) Just build locally"
echo ""
read -p "Enter your choice (1-3): " choice

case $choice in
    1)
        echo ""
        echo "🚀 Deploying to Vercel..."
        echo ""
        
        # Check if vercel CLI is installed
        if ! command -v vercel &> /dev/null; then
            echo "Installing Vercel CLI..."
            npm i -g vercel
        fi
        
        echo "Starting deployment..."
        vercel
        
        echo ""
        echo "✅ Deployment complete!"
        echo "Your app is now live! 🎉"
        ;;
        
    2)
        echo ""
        echo "🚀 Preparing for Netlify..."
        echo ""
        
        # Check if netlify CLI is installed
        if ! command -v netlify &> /dev/null; then
            echo "Installing Netlify CLI..."
            npm i -g netlify-cli
        fi
        
        echo "Building project..."
        npm run build
        
        echo "Starting deployment..."
        netlify deploy
        
        echo ""
        echo "✅ Deployment complete!"
        echo "Your app is now live! 🎉"
        ;;
        
    3)
        echo ""
        echo "🔨 Building project locally..."
        echo ""
        
        npm run build
        
        echo ""
        echo "✅ Build complete!"
        echo "📁 Your production files are in the 'dist' folder"
        echo ""
        echo "Next steps:"
        echo "1. Upload the 'dist' folder to any hosting service"
        echo "2. Or run 'npm run preview' to test locally"
        ;;
        
    *)
        echo ""
        echo "❌ Invalid choice. Please run the script again."
        exit 1
        ;;
esac

echo ""
echo "📚 For more deployment options, see DEPLOYMENT.md"
echo ""
