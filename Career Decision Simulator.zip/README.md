# 🚀 Reality Forking: Career Decision Simulator

**"Don't choose your future blindly—experience it first."**

An immersive web application that lets students and career switchers experience different career paths through VR-style simulations before making life-changing decisions.

![App Preview](https://via.placeholder.com/800x400/8b5cf6/ffffff?text=Career+Decision+Simulator)

## ✨ Features

- 📊 **Interactive Career Simulations** - Experience 5 years of a career in minutes
- 📈 **Data-Driven Insights** - Compare salaries, stress levels, satisfaction, and work-life balance
- 🎨 **Beautiful UI** - Modern, gradient-rich design with smooth animations
- 📱 **Progressive Web App** - Install on any device, works offline
- 🎯 **6 Career Paths** - Software Engineer, Startup Founder, UX Designer, Data Scientist, Product Manager, Digital Marketer
- 🔮 **Timeline Acceleration** - Compressed career experiences with AI-powered simulations

## 🎬 How It Works

1. **Input Your Profile** - Interests, skills, personality traits, risk tolerance
2. **Select Careers** - Choose 2-3 careers to explore
3. **Experience Simulations** - Live through 5 years in each career
4. **Compare Results** - Analyze comprehensive data visualizations
5. **Make Your Decision** - Choose with confidence!

## 🛠️ Tech Stack

- **Frontend**: React 18 + TypeScript
- **Routing**: React Router v7
- **Styling**: Tailwind CSS v4
- **Animations**: Motion (Framer Motion)
- **Charts**: Recharts
- **UI Components**: Radix UI + Custom components
- **Build Tool**: Vite
- **PWA**: vite-plugin-pwa

## 🚀 Quick Deploy

### Deploy to Vercel (Recommended - 2 minutes)

[![Deploy with Vercel](https://vercel.com/button)](https://vercel.com/new/clone?repository-url=https://github.com/yourusername/career-simulator)

1. Click the button above
2. Connect your GitHub
3. Deploy!

### Deploy to Netlify

[![Deploy to Netlify](https://www.netlify.com/img/deploy/button.svg)](https://app.netlify.com/start/deploy)

1. Click the button above
2. Connect repository
3. Deploy automatically

### Manual Deployment

```bash
# Clone the repository
git clone <your-repo-url>

# Install dependencies
npm install

# Build for production
npm run build

# Deploy the 'dist' folder to any hosting service
```

## 💻 Local Development

```bash
# Install dependencies
npm install

# Start development server
npm run dev

# Build for production
npm run build

# Preview production build
npm run preview
```

## 📱 Install as App

Once deployed, your app can be installed on any device:

**Mobile (iOS/Android):**
1. Visit the website
2. Tap "Share" → "Add to Home Screen"
3. Launch from home screen!

**Desktop (Chrome/Edge):**
1. Visit the website
2. Click install icon in address bar
3. App opens in its own window!

## 🎨 Customization

### Change Career Data

Edit `/src/app/data/careers.ts` to modify:
- Career options
- Timeline progressions
- Salary ranges
- Metrics and events

### Modify Styling

- Theme colors: `/src/styles/theme.css`
- Tailwind config: Inline in components
- Animations: Motion props in components

### Add More Features

- Analytics: Add Google Analytics or Plausible
- Backend: Connect to Supabase for user accounts
- AI Recommendations: Integrate OpenAI for personalized suggestions

## 📊 Career Data Structure

```typescript
{
  id: "career-id",
  title: "Career Title",
  icon: "🚀",
  description: "Career description",
  timeline: [
    {
      year: 0,
      role: "Entry Level",
      salary: 70000,
      stress: 60,
      satisfaction: 75,
      workLifeBalance: 70,
      events: ["Event 1", "Event 2"]
    }
  ],
  finalMetrics: {
    avgSalary: 100000,
    riskLevel: 30,
    satisfaction: 85,
    workLifeBalance: 70,
    growthPotential: 90
  }
}
```

## 🎯 Use Cases

- **Students** (High School → College) - Choose major/career path
- **Career Switchers** - Evaluate new career options
- **Universities** - Career counseling tool
- **Career Coaches** - Client decision support
- **EdTech Platforms** - Career guidance feature

## 🌍 Real-World Impact

- ✅ Reduces wrong career choices
- ⏰ Saves years of trial and error
- 💡 Data-driven decision making
- 😊 Increases job satisfaction
- 🌐 Scales globally

## 📝 License

MIT License - feel free to use for personal or commercial projects!

## 🙏 Credits

- Icons: [Lucide React](https://lucide.dev)
- Charts: [Recharts](https://recharts.org)
- UI Components: [Radix UI](https://radix-ui.com)
- Animations: [Motion](https://motion.dev)

## 🤝 Contributing

Contributions welcome! Feel free to:
- Add more career paths
- Improve simulations
- Enhance UI/UX
- Fix bugs

## 📞 Support

Questions? Issues? Suggestions?
- Open an issue on GitHub
- Email: your-email@example.com
- Twitter: @yourusername

---

Made with 💜 by [Your Name]

**Don't choose your future blindly—experience it first!** 🚀
