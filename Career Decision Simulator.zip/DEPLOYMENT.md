# 🚀 Deployment Guide - Reality Forking: Career Decision Simulator

This app is now configured as a **Progressive Web App (PWA)** that can be installed on mobile devices and desktops like a native app!

## 📱 What is a PWA?

A Progressive Web App works on any device and can be installed directly from the browser:
- **Works offline** after first visit
- **Installable** on home screen (iOS, Android, Desktop)
- **Fast loading** with caching
- **App-like experience** without app stores

## 🌐 Deployment Options

### Option 1: Vercel (Recommended - Free & Easy)

1. **Sign up at [vercel.com](https://vercel.com)**

2. **Install Vercel CLI** (optional):
   ```bash
   npm i -g vercel
   ```

3. **Deploy**:
   ```bash
   vercel
   ```
   
   Or **connect your GitHub repo** and Vercel will auto-deploy on every push!

4. **Your app will be live** at: `your-app-name.vercel.app`

### Option 2: Netlify (Free & Easy)

1. **Sign up at [netlify.com](https://netlify.com)**

2. **Drag & drop** your `dist` folder (after building) or connect GitHub

3. **Build settings**:
   - Build command: `npm run build`
   - Publish directory: `dist`

4. **Your app will be live** at: `your-app-name.netlify.app`

### Option 3: GitHub Pages (Free)

1. **Install gh-pages**:
   ```bash
   npm install --save-dev gh-pages
   ```

2. **Update package.json**:
   ```json
   {
     "scripts": {
       "deploy": "npm run build && gh-pages -d dist"
     },
     "homepage": "https://yourusername.github.io/career-simulator"
   }
   ```

3. **Deploy**:
   ```bash
   npm run deploy
   ```

### Option 4: Firebase Hosting (Free)

1. **Install Firebase CLI**:
   ```bash
   npm install -g firebase-tools
   ```

2. **Login and initialize**:
   ```bash
   firebase login
   firebase init hosting
   ```

3. **Configure**:
   - Public directory: `dist`
   - Single-page app: `Yes`

4. **Build and deploy**:
   ```bash
   npm run build
   firebase deploy
   ```

## 📲 Installing the App

Once deployed, users can install your app:

### On Mobile (iOS/Android):
1. Open the website in browser (Safari/Chrome)
2. Tap the **Share** button
3. Select **"Add to Home Screen"**
4. App icon appears on home screen!

### On Desktop:
1. Open the website in Chrome/Edge
2. Look for **Install icon** in address bar
3. Click to install
4. App opens in its own window!

## 🔧 Build Commands

```bash
# Development
npm run dev

# Build for production
npm run build

# Preview production build
npm run preview
```

## 🎨 Customizing App Icons

The app uses SVG icons in `/public/`. To customize:

1. Create PNG versions:
   - `icon-192.png` (192x192px)
   - `icon-512.png` (512x512px)

2. Use tools like:
   - [Figma](https://figma.com)
   - [Canva](https://canva.com)
   - [Favicon.io](https://favicon.io)

3. Replace the SVG files with PNGs

## 📊 Analytics (Optional)

Add Google Analytics or other tracking:

1. **Google Analytics**:
   ```bash
   npm install react-ga4
   ```

2. **Initialize in App.tsx**:
   ```typescript
   import ReactGA from "react-ga4";
   
   ReactGA.initialize("YOUR-GA-MEASUREMENT-ID");
   ```

## 🔒 Environment Variables

For any API keys or secrets:

1. Create `.env` file:
   ```
   VITE_API_KEY=your_key_here
   ```

2. Access in code:
   ```typescript
   const apiKey = import.meta.env.VITE_API_KEY;
   ```

3. Add to deployment platform's environment variables

## 🌍 Custom Domain

All platforms support custom domains:

1. **Buy a domain** (Namecheap, Google Domains, etc.)
2. **Add CNAME record** pointing to your deployment
3. **Configure in platform settings**
4. **Enable HTTPS** (automatic on most platforms)

## 📱 App Store Deployment (Future)

To convert this to native apps:

### For iOS/Android:
1. Use [Capacitor](https://capacitorjs.com/):
   ```bash
   npm install @capacitor/core @capacitor/cli
   npx cap init
   npx cap add ios
   npx cap add android
   ```

2. Build and deploy to App Store / Play Store

### Alternative:
- [PWABuilder](https://www.pwabuilder.com/) - converts PWA to native apps

## 🎯 Performance Tips

1. **Enable Compression** on hosting platform
2. **Use CDN** for static assets
3. **Monitor with**:
   - [Lighthouse](https://developers.google.com/web/tools/lighthouse)
   - [PageSpeed Insights](https://pagespeed.web.dev/)

## 💡 Marketing Your App

1. **Share the link** on social media
2. **Add QR code** for easy mobile access
3. **SEO**: Add meta tags (already included)
4. **Submit to**:
   - [Product Hunt](https://producthunt.com)
   - [Indie Hackers](https://indiehackers.com)

## 🆘 Troubleshooting

### Build fails:
```bash
# Clear cache and reinstall
rm -rf node_modules dist
npm install
npm run build
```

### PWA not installing:
- Must be served over HTTPS
- Check manifest.json is accessible
- Verify icons exist

### Routing issues:
- Add `_redirects` file (Netlify) or `vercel.json` (Vercel)
- Configure SPA routing

## 📞 Support

Need help? Check:
- [Vite Docs](https://vitejs.dev)
- [PWA Docs](https://web.dev/progressive-web-apps/)
- Platform-specific docs

---

## 🎉 Quick Start (Fastest Way)

1. **Push to GitHub**
2. **Connect to Vercel** (1-click)
3. **Share your link!**

Your app will be live in ~2 minutes! 🚀
