// Career data structure and mock data

export interface Career {
  id: string;
  title: string;
  icon: string;
  description: string;
  dailyTasks: string[];
  challenges: string[];
  skills: string[];
  timeline: {
    year: number;
    role: string;
    salary: number;
    stress: number;
    satisfaction: number;
    workLifeBalance: number;
    events: string[];
  }[];
  finalMetrics: {
    avgSalary: number;
    riskLevel: number;
    satisfaction: number;
    workLifeBalance: number;
    growthPotential: number;
  };
}

export const careers: Career[] = [
  {
    id: "software-engineer",
    title: "Software Engineer",
    icon: "💻",
    description: "Build and design software systems that power modern technology",
    dailyTasks: [
      "Write clean, efficient code",
      "Debug and fix software issues",
      "Collaborate with team in daily standups",
      "Review code from teammates",
      "Plan technical architecture"
    ],
    challenges: [
      "Tight deadlines and pressure",
      "Keeping up with new technologies",
      "Complex debugging sessions",
      "Balancing technical debt"
    ],
    skills: ["Problem Solving", "Logical Thinking", "Attention to Detail", "Continuous Learning"],
    timeline: [
      {
        year: 0,
        role: "Junior Developer",
        salary: 70000,
        stress: 60,
        satisfaction: 75,
        workLifeBalance: 70,
        events: ["Started first job", "Learning company codebase", "First bug fix shipped"]
      },
      {
        year: 1,
        role: "Junior Developer",
        salary: 75000,
        stress: 55,
        satisfaction: 80,
        workLifeBalance: 75,
        events: ["Built first major feature", "Got praise from senior dev", "Attended tech conference"]
      },
      {
        year: 2,
        role: "Mid-Level Developer",
        salary: 95000,
        stress: 65,
        satisfaction: 85,
        workLifeBalance: 65,
        events: ["Promoted to mid-level", "Leading small projects", "Mentoring interns"]
      },
      {
        year: 3,
        role: "Mid-Level Developer",
        salary: 105000,
        stress: 60,
        satisfaction: 88,
        workLifeBalance: 70,
        events: ["Optimized critical system", "Speaking at meetups", "Remote work approved"]
      },
      {
        year: 4,
        role: "Senior Developer",
        salary: 130000,
        stress: 70,
        satisfaction: 90,
        workLifeBalance: 60,
        events: ["Promoted to senior", "Architecting new systems", "Leading team of 5"]
      },
      {
        year: 5,
        role: "Senior Developer",
        salary: 145000,
        stress: 65,
        satisfaction: 92,
        workLifeBalance: 70,
        events: ["Industry recognition", "Open source contributions", "Perfect work-life balance"]
      }
    ],
    finalMetrics: {
      avgSalary: 103000,
      riskLevel: 30,
      satisfaction: 85,
      workLifeBalance: 68,
      growthPotential: 90
    }
  },
  {
    id: "startup-founder",
    title: "Startup Founder",
    icon: "🚀",
    description: "Build your own company from scratch and revolutionize an industry",
    dailyTasks: [
      "Pitch to investors",
      "Product development decisions",
      "Hire and manage team",
      "Customer development",
      "Strategic planning"
    ],
    challenges: [
      "Extreme uncertainty and risk",
      "Financial instability",
      "Long working hours",
      "High failure rate",
      "Constant stress"
    ],
    skills: ["Resilience", "Vision", "Leadership", "Risk-Taking", "Resourcefulness"],
    timeline: [
      {
        year: 0,
        role: "Founder",
        salary: 0,
        stress: 95,
        satisfaction: 60,
        workLifeBalance: 20,
        events: ["Quit job to start company", "Building MVP", "Living on savings"]
      },
      {
        year: 1,
        role: "Founder & CEO",
        salary: 30000,
        stress: 90,
        satisfaction: 70,
        workLifeBalance: 25,
        events: ["First 100 customers", "Raised seed round", "Hired first 3 employees"]
      },
      {
        year: 2,
        role: "Founder & CEO",
        salary: 50000,
        stress: 88,
        satisfaction: 75,
        workLifeBalance: 30,
        events: ["Product-market fit", "Featured in TechCrunch", "Team of 15 people"]
      },
      {
        year: 3,
        role: "Founder & CEO",
        salary: 80000,
        stress: 85,
        satisfaction: 80,
        workLifeBalance: 35,
        events: ["Series A funding", "Expanded to new markets", "Revenue growing 300%"]
      },
      {
        year: 4,
        role: "Founder & CEO",
        salary: 120000,
        stress: 80,
        satisfaction: 90,
        workLifeBalance: 45,
        events: ["Profitable!", "50+ employees", "Award for innovation"]
      },
      {
        year: 5,
        role: "Founder & CEO",
        salary: 200000,
        stress: 70,
        satisfaction: 95,
        workLifeBalance: 55,
        events: ["Acquired by major company", "Life-changing exit", "Started angel investing"]
      }
    ],
    finalMetrics: {
      avgSalary: 80000,
      riskLevel: 95,
      satisfaction: 78,
      workLifeBalance: 35,
      growthPotential: 100
    }
  },
  {
    id: "ux-designer",
    title: "UX/UI Designer",
    icon: "🎨",
    description: "Craft beautiful and intuitive user experiences that delight millions",
    dailyTasks: [
      "User research and interviews",
      "Create wireframes and prototypes",
      "Design user interfaces",
      "Conduct usability testing",
      "Collaborate with developers"
    ],
    challenges: [
      "Subjective feedback and criticism",
      "Balancing user needs vs business goals",
      "Keeping up with design trends",
      "Dealing with unclear requirements"
    ],
    skills: ["Creativity", "Empathy", "Communication", "Visual Thinking", "Problem Solving"],
    timeline: [
      {
        year: 0,
        role: "Junior Designer",
        salary: 55000,
        stress: 50,
        satisfaction: 80,
        workLifeBalance: 80,
        events: ["First design job", "Learning Figma & tools", "Small feature designs"]
      },
      {
        year: 1,
        role: "Junior Designer",
        salary: 62000,
        stress: 45,
        satisfaction: 85,
        workLifeBalance: 85,
        events: ["Led redesign of key flow", "Positive user feedback", "Design system contribution"]
      },
      {
        year: 2,
        role: "UX Designer",
        salary: 78000,
        stress: 55,
        satisfaction: 88,
        workLifeBalance: 75,
        events: ["Promoted to mid-level", "Conducting user research", "Presenting to executives"]
      },
      {
        year: 3,
        role: "UX Designer",
        salary: 88000,
        stress: 50,
        satisfaction: 90,
        workLifeBalance: 80,
        events: ["Design award winner", "Mentoring junior designers", "Building design system"]
      },
      {
        year: 4,
        role: "Senior Designer",
        salary: 110000,
        stress: 60,
        satisfaction: 92,
        workLifeBalance: 70,
        events: ["Promoted to senior", "Leading design team", "Speaking at conferences"]
      },
      {
        year: 5,
        role: "Lead Designer",
        salary: 135000,
        stress: 55,
        satisfaction: 95,
        workLifeBalance: 75,
        events: ["Design director role", "Company-wide impact", "Perfect team culture"]
      }
    ],
    finalMetrics: {
      avgSalary: 88000,
      riskLevel: 25,
      satisfaction: 88,
      workLifeBalance: 78,
      growthPotential: 75
    }
  },
  {
    id: "data-scientist",
    title: "Data Scientist",
    icon: "📊",
    description: "Extract insights from data and build AI models that predict the future",
    dailyTasks: [
      "Analyze large datasets",
      "Build machine learning models",
      "Create data visualizations",
      "Present insights to stakeholders",
      "Optimize algorithms"
    ],
    challenges: [
      "Messy, incomplete data",
      "Complex statistical concepts",
      "High expectations vs reality",
      "Translating technical to non-technical"
    ],
    skills: ["Analytical Thinking", "Mathematics", "Programming", "Communication", "Curiosity"],
    timeline: [
      {
        year: 0,
        role: "Junior Data Scientist",
        salary: 75000,
        stress: 65,
        satisfaction: 70,
        workLifeBalance: 70,
        events: ["First data science role", "Learning tools & frameworks", "First model deployed"]
      },
      {
        year: 1,
        role: "Junior Data Scientist",
        salary: 85000,
        stress: 60,
        satisfaction: 78,
        workLifeBalance: 72,
        events: ["Model improved revenue", "Published first paper", "Kaggle competition winner"]
      },
      {
        year: 2,
        role: "Data Scientist",
        salary: 105000,
        stress: 68,
        satisfaction: 82,
        workLifeBalance: 68,
        events: ["Promoted to mid-level", "Leading ML projects", "Building data pipelines"]
      },
      {
        year: 3,
        role: "Data Scientist",
        salary: 120000,
        stress: 65,
        satisfaction: 85,
        workLifeBalance: 70,
        events: ["AI model in production", "Conference speaker", "Team expansion"]
      },
      {
        year: 4,
        role: "Senior Data Scientist",
        salary: 145000,
        stress: 70,
        satisfaction: 88,
        workLifeBalance: 65,
        events: ["Promoted to senior", "Research breakthroughs", "Mentoring others"]
      },
      {
        year: 5,
        role: "Lead Data Scientist",
        salary: 170000,
        stress: 68,
        satisfaction: 90,
        workLifeBalance: 68,
        events: ["Leading data science team", "Patent filed", "Industry recognition"]
      }
    ],
    finalMetrics: {
      avgSalary: 117000,
      riskLevel: 35,
      satisfaction: 82,
      workLifeBalance: 69,
      growthPotential: 95
    }
  },
  {
    id: "product-manager",
    title: "Product Manager",
    icon: "📱",
    description: "Define product vision and strategy, bridging tech, design, and business",
    dailyTasks: [
      "Define product roadmap",
      "Write product requirements",
      "Coordinate cross-functional teams",
      "Analyze user feedback and metrics",
      "Make strategic decisions"
    ],
    challenges: [
      "Balancing stakeholder demands",
      "No direct authority over team",
      "Dealing with ambiguity",
      "Taking blame when things fail"
    ],
    skills: ["Strategic Thinking", "Communication", "Leadership", "Data Analysis", "Empathy"],
    timeline: [
      {
        year: 0,
        role: "Associate PM",
        salary: 80000,
        stress: 70,
        satisfaction: 72,
        workLifeBalance: 65,
        events: ["First PM role", "Learning the ropes", "Shipping small features"]
      },
      {
        year: 1,
        role: "Associate PM",
        salary: 90000,
        stress: 68,
        satisfaction: 78,
        workLifeBalance: 68,
        events: ["Led successful product launch", "User growth 50%", "Cross-team collaboration"]
      },
      {
        year: 2,
        role: "Product Manager",
        salary: 115000,
        stress: 75,
        satisfaction: 82,
        workLifeBalance: 60,
        events: ["Promoted to PM", "Managing product line", "Stakeholder presentations"]
      },
      {
        year: 3,
        role: "Product Manager",
        salary: 130000,
        stress: 72,
        satisfaction: 85,
        workLifeBalance: 65,
        events: ["Pivoted failing product", "Revenue milestone hit", "Team expansion"]
      },
      {
        year: 4,
        role: "Senior PM",
        salary: 155000,
        stress: 78,
        satisfaction: 88,
        workLifeBalance: 55,
        events: ["Promoted to senior PM", "Multiple products", "Strategic planning"]
      },
      {
        year: 5,
        role: "Group PM",
        salary: 185000,
        stress: 75,
        satisfaction: 90,
        workLifeBalance: 60,
        events: ["Director-level role", "Leading PM team", "Company-wide impact"]
      }
    ],
    finalMetrics: {
      avgSalary: 126000,
      riskLevel: 40,
      satisfaction: 83,
      workLifeBalance: 62,
      growthPotential: 85
    }
  },
  {
    id: "digital-marketer",
    title: "Digital Marketer",
    icon: "📈",
    description: "Drive growth and customer acquisition through creative marketing strategies",
    dailyTasks: [
      "Plan marketing campaigns",
      "Create content and copy",
      "Analyze campaign metrics",
      "Manage social media",
      "A/B test marketing strategies"
    ],
    challenges: [
      "Constantly changing algorithms",
      "Proving ROI",
      "Creative burnout",
      "Tight budgets"
    ],
    skills: ["Creativity", "Analytical Skills", "Communication", "Adaptability", "Tech Savvy"],
    timeline: [
      {
        year: 0,
        role: "Marketing Coordinator",
        salary: 45000,
        stress: 55,
        satisfaction: 70,
        workLifeBalance: 75,
        events: ["First marketing job", "Running social media", "Learning marketing tools"]
      },
      {
        year: 1,
        role: "Marketing Specialist",
        salary: 52000,
        stress: 58,
        satisfaction: 75,
        workLifeBalance: 73,
        events: ["Viral campaign success", "Grew followers 200%", "Email marketing wins"]
      },
      {
        year: 2,
        role: "Digital Marketer",
        salary: 65000,
        stress: 60,
        satisfaction: 80,
        workLifeBalance: 70,
        events: ["Promoted to marketer", "Managing campaigns", "SEO expertise gained"]
      },
      {
        year: 3,
        role: "Senior Marketer",
        salary: 78000,
        stress: 62,
        satisfaction: 83,
        workLifeBalance: 72,
        events: ["Senior promotion", "Leading campaigns", "Influencer partnerships"]
      },
      {
        year: 4,
        role: "Marketing Manager",
        salary: 95000,
        stress: 68,
        satisfaction: 85,
        workLifeBalance: 65,
        events: ["Manager role", "Building team", "Budget ownership"]
      },
      {
        year: 5,
        role: "Senior Marketing Manager",
        salary: 115000,
        stress: 65,
        satisfaction: 88,
        workLifeBalance: 68,
        events: ["Multi-channel mastery", "Award-winning campaigns", "Mentoring team"]
      }
    ],
    finalMetrics: {
      avgSalary: 75000,
      riskLevel: 30,
      satisfaction: 80,
      workLifeBalance: 71,
      growthPotential: 70
    }
  }
];

export interface UserProfile {
  interests: string[];
  skills: string[];
  personality: string[];
  riskTolerance: number;
  workLifePreference: number;
}
