import { useNavigate } from "react-router";
import { motion } from "motion/react";
import { Button } from "../components/ui/button";
import { Card } from "../components/ui/card";
import {
  LineChart,
  Line,
  BarChart,
  Bar,
  RadarChart,
  PolarGrid,
  PolarAngleAxis,
  PolarRadiusAxis,
  Radar,
  XAxis,
  YAxis,
  CartesianGrid,
  Tooltip,
  Legend,
  ResponsiveContainer,
} from "recharts";
import { TrendingUp, DollarSign, Shield, Smile, Scale, Trophy } from "lucide-react";
import { careers } from "../data/careers";

export function Comparison() {
  const navigate = useNavigate();
  const selectedCareerIds = JSON.parse(
    sessionStorage.getItem("selectedCareers") || "[]"
  );
  const selectedCareers = careers.filter((c) => selectedCareerIds.includes(c.id));

  // Prepare data for salary progression chart
  const salaryData = Array.from({ length: 6 }, (_, i) => {
    const data: Record<string, number> = { year: i };
    selectedCareers.forEach((career) => {
      data[career.title] = career.timeline[i].salary;
    });
    return data;
  });

  // Prepare data for metrics over time
  const satisfactionData = Array.from({ length: 6 }, (_, i) => {
    const data: Record<string, number> = { year: i };
    selectedCareers.forEach((career) => {
      data[career.title] = career.timeline[i].satisfaction;
    });
    return data;
  });

  const stressData = Array.from({ length: 6 }, (_, i) => {
    const data: Record<string, number> = { year: i };
    selectedCareers.forEach((career) => {
      data[career.title] = career.timeline[i].stress;
    });
    return data;
  });

  const workLifeData = Array.from({ length: 6 }, (_, i) => {
    const data: Record<string, number> = { year: i };
    selectedCareers.forEach((career) => {
      data[career.title] = career.timeline[i].workLifeBalance;
    });
    return data;
  });

  // Prepare radar chart data
  const radarData = [
    {
      metric: "Avg Salary",
      ...selectedCareers.reduce((acc, career) => {
        acc[career.title] = (career.finalMetrics.avgSalary / 2000).toFixed(0);
        return acc;
      }, {} as Record<string, string>),
    },
    {
      metric: "Low Risk",
      ...selectedCareers.reduce((acc, career) => {
        acc[career.title] = 100 - career.finalMetrics.riskLevel;
        return acc;
      }, {} as Record<string, number>),
    },
    {
      metric: "Satisfaction",
      ...selectedCareers.reduce((acc, career) => {
        acc[career.title] = career.finalMetrics.satisfaction;
        return acc;
      }, {} as Record<string, number>),
    },
    {
      metric: "Work-Life",
      ...selectedCareers.reduce((acc, career) => {
        acc[career.title] = career.finalMetrics.workLifeBalance;
        return acc;
      }, {} as Record<string, number>),
    },
    {
      metric: "Growth",
      ...selectedCareers.reduce((acc, career) => {
        acc[career.title] = career.finalMetrics.growthPotential;
        return acc;
      }, {} as Record<string, number>),
    },
  ];

  const colors = ["#8b5cf6", "#ec4899", "#06b6d4", "#10b981", "#f59e0b"];

  return (
    <div className="min-h-screen bg-gradient-to-br from-indigo-900 via-purple-900 to-pink-900 text-white">
      <div className="container mx-auto px-4 py-12 max-w-7xl">
        <motion.div
          initial={{ opacity: 0, y: -20 }}
          animate={{ opacity: 1, y: 0 }}
          className="mb-8 text-center"
        >
          <h1 className="mb-4">Step 4: Career Comparison</h1>
          <p className="text-xl text-gray-300">
            Here's how your selected careers stack up against each other
          </p>
        </motion.div>

        {/* Summary Cards */}
        <div className="grid md:grid-cols-3 gap-6 mb-8">
          {selectedCareers.map((career, index) => (
            <motion.div
              key={career.id}
              initial={{ opacity: 0, y: 20 }}
              animate={{ opacity: 1, y: 0 }}
              transition={{ delay: index * 0.1 }}
            >
              <Card className="bg-white/10 backdrop-blur-lg border-white/20 p-6 h-full">
                <div className="flex items-center gap-3 mb-4">
                  <div className="text-4xl">{career.icon}</div>
                  <h3 className="font-semibold text-white">{career.title}</h3>
                </div>

                <div className="space-y-3">
                  <div className="flex items-center justify-between p-2 bg-white/5 rounded">
                    <div className="flex items-center gap-2 text-sm">
                      <DollarSign className="w-4 h-4 text-green-400" />
                      <span className="text-gray-300">Avg Salary</span>
                    </div>
                    <span className="font-semibold">
                      ${(career.finalMetrics.avgSalary / 1000).toFixed(0)}K
                    </span>
                  </div>

                  <div className="flex items-center justify-between p-2 bg-white/5 rounded">
                    <div className="flex items-center gap-2 text-sm">
                      <Shield className="w-4 h-4 text-blue-400" />
                      <span className="text-gray-300">Risk Level</span>
                    </div>
                    <span
                      className={`font-semibold ${
                        career.finalMetrics.riskLevel > 70
                          ? "text-red-400"
                          : career.finalMetrics.riskLevel > 40
                          ? "text-yellow-400"
                          : "text-green-400"
                      }`}
                    >
                      {career.finalMetrics.riskLevel}%
                    </span>
                  </div>

                  <div className="flex items-center justify-between p-2 bg-white/5 rounded">
                    <div className="flex items-center gap-2 text-sm">
                      <Smile className="w-4 h-4 text-pink-400" />
                      <span className="text-gray-300">Satisfaction</span>
                    </div>
                    <span className="font-semibold">
                      {career.finalMetrics.satisfaction}%
                    </span>
                  </div>

                  <div className="flex items-center justify-between p-2 bg-white/5 rounded">
                    <div className="flex items-center gap-2 text-sm">
                      <Scale className="w-4 h-4 text-cyan-400" />
                      <span className="text-gray-300">Work-Life</span>
                    </div>
                    <span className="font-semibold">
                      {career.finalMetrics.workLifeBalance}%
                    </span>
                  </div>

                  <div className="flex items-center justify-between p-2 bg-white/5 rounded">
                    <div className="flex items-center gap-2 text-sm">
                      <Trophy className="w-4 h-4 text-yellow-400" />
                      <span className="text-gray-300">Growth</span>
                    </div>
                    <span className="font-semibold">
                      {career.finalMetrics.growthPotential}%
                    </span>
                  </div>
                </div>
              </Card>
            </motion.div>
          ))}
        </div>

        {/* Charts */}
        <div className="space-y-8">
          {/* Salary Progression */}
          <motion.div
            initial={{ opacity: 0, y: 20 }}
            animate={{ opacity: 1, y: 0 }}
            transition={{ delay: 0.3 }}
          >
            <Card className="bg-white/10 backdrop-blur-lg border-white/20 p-6">
              <div className="flex items-center gap-2 mb-4">
                <TrendingUp className="w-6 h-6 text-green-400" />
                <h2 className="text-white">Salary Progression Over 5 Years</h2>
              </div>
              <ResponsiveContainer width="100%" height={300}>
                <LineChart data={salaryData}>
                  <CartesianGrid strokeDasharray="3 3" stroke="rgba(255,255,255,0.1)" />
                  <XAxis
                    dataKey="year"
                    stroke="rgba(255,255,255,0.5)"
                    label={{ value: "Year", position: "insideBottom", offset: -5 }}
                  />
                  <YAxis
                    stroke="rgba(255,255,255,0.5)"
                    tickFormatter={(value) => `$${(value / 1000).toFixed(0)}K`}
                  />
                  <Tooltip
                    contentStyle={{
                      backgroundColor: "rgba(0,0,0,0.8)",
                      border: "1px solid rgba(255,255,255,0.2)",
                      borderRadius: "8px",
                    }}
                    formatter={(value: number) => [`$${value.toLocaleString()}`, ""]}
                  />
                  <Legend />
                  {selectedCareers.map((career, i) => (
                    <Line
                      key={career.id}
                      type="monotone"
                      dataKey={career.title}
                      stroke={colors[i]}
                      strokeWidth={3}
                      dot={{ r: 4 }}
                    />
                  ))}
                </LineChart>
              </ResponsiveContainer>
            </Card>
          </motion.div>

          {/* Two column charts */}
          <div className="grid lg:grid-cols-2 gap-6">
            {/* Satisfaction Over Time */}
            <motion.div
              initial={{ opacity: 0, x: -20 }}
              animate={{ opacity: 1, x: 0 }}
              transition={{ delay: 0.4 }}
            >
              <Card className="bg-white/10 backdrop-blur-lg border-white/20 p-6">
                <div className="flex items-center gap-2 mb-4">
                  <Smile className="w-6 h-6 text-pink-400" />
                  <h3 className="font-semibold text-white">Satisfaction Over Time</h3>
                </div>
                <ResponsiveContainer width="100%" height={250}>
                  <LineChart data={satisfactionData}>
                    <CartesianGrid strokeDasharray="3 3" stroke="rgba(255,255,255,0.1)" />
                    <XAxis dataKey="year" stroke="rgba(255,255,255,0.5)" />
                    <YAxis stroke="rgba(255,255,255,0.5)" domain={[0, 100]} />
                    <Tooltip
                      contentStyle={{
                        backgroundColor: "rgba(0,0,0,0.8)",
                        border: "1px solid rgba(255,255,255,0.2)",
                        borderRadius: "8px",
                      }}
                      formatter={(value: number) => [`${value}%`, ""]}
                    />
                    {selectedCareers.map((career, i) => (
                      <Line
                        key={career.id}
                        type="monotone"
                        dataKey={career.title}
                        stroke={colors[i]}
                        strokeWidth={2}
                      />
                    ))}
                  </LineChart>
                </ResponsiveContainer>
              </Card>
            </motion.div>

            {/* Stress Levels */}
            <motion.div
              initial={{ opacity: 0, x: 20 }}
              animate={{ opacity: 1, x: 0 }}
              transition={{ delay: 0.4 }}
            >
              <Card className="bg-white/10 backdrop-blur-lg border-white/20 p-6">
                <div className="flex items-center gap-2 mb-4">
                  <TrendingUp className="w-6 h-6 text-red-400" />
                  <h3 className="font-semibold text-white">Stress Levels Over Time</h3>
                </div>
                <ResponsiveContainer width="100%" height={250}>
                  <LineChart data={stressData}>
                    <CartesianGrid strokeDasharray="3 3" stroke="rgba(255,255,255,0.1)" />
                    <XAxis dataKey="year" stroke="rgba(255,255,255,0.5)" />
                    <YAxis stroke="rgba(255,255,255,0.5)" domain={[0, 100]} />
                    <Tooltip
                      contentStyle={{
                        backgroundColor: "rgba(0,0,0,0.8)",
                        border: "1px solid rgba(255,255,255,0.2)",
                        borderRadius: "8px",
                      }}
                      formatter={(value: number) => [`${value}%`, ""]}
                    />
                    {selectedCareers.map((career, i) => (
                      <Line
                        key={career.id}
                        type="monotone"
                        dataKey={career.title}
                        stroke={colors[i]}
                        strokeWidth={2}
                      />
                    ))}
                  </LineChart>
                </ResponsiveContainer>
              </Card>
            </motion.div>
          </div>

          {/* Radar Chart and Work-Life Balance */}
          <div className="grid lg:grid-cols-2 gap-6">
            {/* Overall Comparison Radar */}
            <motion.div
              initial={{ opacity: 0, scale: 0.9 }}
              animate={{ opacity: 1, scale: 1 }}
              transition={{ delay: 0.5 }}
            >
              <Card className="bg-white/10 backdrop-blur-lg border-white/20 p-6">
                <h3 className="font-semibold text-white mb-4">Overall Comparison</h3>
                <ResponsiveContainer width="100%" height={300}>
                  <RadarChart data={radarData}>
                    <PolarGrid stroke="rgba(255,255,255,0.2)" />
                    <PolarAngleAxis
                      dataKey="metric"
                      stroke="rgba(255,255,255,0.7)"
                      tick={{ fill: "rgba(255,255,255,0.7)" }}
                    />
                    <PolarRadiusAxis
                      angle={90}
                      domain={[0, 100]}
                      stroke="rgba(255,255,255,0.3)"
                    />
                    {selectedCareers.map((career, i) => (
                      <Radar
                        key={career.id}
                        name={career.title}
                        dataKey={career.title}
                        stroke={colors[i]}
                        fill={colors[i]}
                        fillOpacity={0.2}
                        strokeWidth={2}
                      />
                    ))}
                    <Legend />
                    <Tooltip
                      contentStyle={{
                        backgroundColor: "rgba(0,0,0,0.8)",
                        border: "1px solid rgba(255,255,255,0.2)",
                        borderRadius: "8px",
                      }}
                    />
                  </RadarChart>
                </ResponsiveContainer>
              </Card>
            </motion.div>

            {/* Work-Life Balance */}
            <motion.div
              initial={{ opacity: 0, scale: 0.9 }}
              animate={{ opacity: 1, scale: 1 }}
              transition={{ delay: 0.5 }}
            >
              <Card className="bg-white/10 backdrop-blur-lg border-white/20 p-6">
                <div className="flex items-center gap-2 mb-4">
                  <Scale className="w-6 h-6 text-blue-400" />
                  <h3 className="font-semibold text-white">Work-Life Balance Over Time</h3>
                </div>
                <ResponsiveContainer width="100%" height={250}>
                  <BarChart data={workLifeData}>
                    <CartesianGrid strokeDasharray="3 3" stroke="rgba(255,255,255,0.1)" />
                    <XAxis dataKey="year" stroke="rgba(255,255,255,0.5)" />
                    <YAxis stroke="rgba(255,255,255,0.5)" domain={[0, 100]} />
                    <Tooltip
                      contentStyle={{
                        backgroundColor: "rgba(0,0,0,0.8)",
                        border: "1px solid rgba(255,255,255,0.2)",
                        borderRadius: "8px",
                      }}
                      formatter={(value: number) => [`${value}%`, ""]}
                    />
                    <Legend />
                    {selectedCareers.map((career, i) => (
                      <Bar
                        key={career.id}
                        dataKey={career.title}
                        fill={colors[i]}
                        opacity={0.8}
                      />
                    ))}
                  </BarChart>
                </ResponsiveContainer>
              </Card>
            </motion.div>
          </div>
        </div>

        {/* CTA */}
        <motion.div
          initial={{ opacity: 0, y: 20 }}
          animate={{ opacity: 1, y: 0 }}
          transition={{ delay: 0.6 }}
          className="mt-12 text-center"
        >
          <Button
            onClick={() => navigate("/decision")}
            size="lg"
            className="bg-gradient-to-r from-purple-600 to-pink-600 hover:from-purple-700 hover:to-pink-700 text-white px-12 py-6 text-xl rounded-full shadow-2xl"
          >
            Make Your Decision
          </Button>
        </motion.div>
      </div>
    </div>
  );
}
