import { useState } from "react";
import { useNavigate } from "react-router";
import { motion } from "motion/react";
import { Button } from "../components/ui/button";
import { Card } from "../components/ui/card";
import { Badge } from "../components/ui/badge";
import { ArrowRight, Check, Info } from "lucide-react";
import { careers } from "../data/careers";

export function CareerSelection() {
  const navigate = useNavigate();
  const [selectedCareers, setSelectedCareers] = useState<string[]>([]);

  const toggleCareer = (careerId: string) => {
    if (selectedCareers.includes(careerId)) {
      setSelectedCareers(selectedCareers.filter((id) => id !== careerId));
    } else if (selectedCareers.length < 3) {
      setSelectedCareers([...selectedCareers, careerId]);
    }
  };

  const handleContinue = () => {
    sessionStorage.setItem("selectedCareers", JSON.stringify(selectedCareers));
    // Navigate to first career simulation
    navigate(`/simulation/${selectedCareers[0]}`);
  };

  return (
    <div className="min-h-screen bg-gradient-to-br from-blue-900 via-indigo-900 to-purple-900 text-white">
      <div className="container mx-auto px-4 py-12 max-w-6xl">
        <motion.div
          initial={{ opacity: 0, y: -20 }}
          animate={{ opacity: 1, y: 0 }}
          className="mb-8 text-center"
        >
          <h1 className="mb-4">Step 2: Choose Careers to Explore</h1>
          <p className="text-xl text-gray-300 mb-2">
            Select 2-3 careers you want to experience
          </p>
          <div className="inline-flex items-center gap-2 bg-blue-500/20 backdrop-blur-sm px-4 py-2 rounded-full border border-blue-400/30">
            <Info className="w-4 h-4 text-blue-300" />
            <span className="text-sm text-blue-200">
              Selected: {selectedCareers.length} / 3
            </span>
          </div>
        </motion.div>

        <div className="grid md:grid-cols-2 lg:grid-cols-3 gap-6 mb-8">
          {careers.map((career, index) => {
            const isSelected = selectedCareers.includes(career.id);
            const canSelect = selectedCareers.length < 3 || isSelected;

            return (
              <motion.div
                key={career.id}
                initial={{ opacity: 0, scale: 0.9 }}
                animate={{ opacity: 1, scale: 1 }}
                transition={{ delay: index * 0.1 }}
              >
                <Card
                  className={`relative overflow-hidden transition-all cursor-pointer h-full ${
                    isSelected
                      ? "bg-gradient-to-br from-purple-600/40 to-pink-600/40 border-purple-400 border-2 shadow-xl shadow-purple-500/20"
                      : canSelect
                      ? "bg-white/10 backdrop-blur-lg border-white/20 hover:border-white/40"
                      : "bg-white/5 backdrop-blur-lg border-white/10 opacity-50 cursor-not-allowed"
                  }`}
                  onClick={() => canSelect && toggleCareer(career.id)}
                >
                  {isSelected && (
                    <motion.div
                      initial={{ scale: 0 }}
                      animate={{ scale: 1 }}
                      className="absolute top-4 right-4 w-8 h-8 bg-green-500 rounded-full flex items-center justify-center z-10"
                    >
                      <Check className="w-5 h-5 text-white" />
                    </motion.div>
                  )}

                  <div className="p-6">
                    <div className="text-5xl mb-4">{career.icon}</div>
                    <h3 className="text-xl font-semibold mb-2 text-white">
                      {career.title}
                    </h3>
                    <p className="text-gray-300 text-sm mb-4">{career.description}</p>

                    <div className="space-y-3">
                      <div>
                        <p className="text-xs font-semibold text-gray-400 mb-2">
                          KEY SKILLS NEEDED:
                        </p>
                        <div className="flex flex-wrap gap-1">
                          {career.skills.slice(0, 3).map((skill) => (
                            <Badge
                              key={skill}
                              variant="secondary"
                              className="text-xs bg-white/10 text-white border-white/20"
                            >
                              {skill}
                            </Badge>
                          ))}
                        </div>
                      </div>

                      <div>
                        <p className="text-xs font-semibold text-gray-400 mb-2">
                          QUICK STATS:
                        </p>
                        <div className="grid grid-cols-2 gap-2 text-xs">
                          <div className="bg-black/20 rounded px-2 py-1">
                            <span className="text-gray-400">Avg Salary:</span>
                            <br />
                            <span className="text-white font-semibold">
                              ${(career.finalMetrics.avgSalary / 1000).toFixed(0)}K
                            </span>
                          </div>
                          <div className="bg-black/20 rounded px-2 py-1">
                            <span className="text-gray-400">Risk:</span>
                            <br />
                            <span className="text-white font-semibold">
                              {career.finalMetrics.riskLevel}%
                            </span>
                          </div>
                          <div className="bg-black/20 rounded px-2 py-1">
                            <span className="text-gray-400">Satisfaction:</span>
                            <br />
                            <span className="text-white font-semibold">
                              {career.finalMetrics.satisfaction}%
                            </span>
                          </div>
                          <div className="bg-black/20 rounded px-2 py-1">
                            <span className="text-gray-400">Work-Life:</span>
                            <br />
                            <span className="text-white font-semibold">
                              {career.finalMetrics.workLifeBalance}%
                            </span>
                          </div>
                        </div>
                      </div>
                    </div>
                  </div>

                  {isSelected && (
                    <motion.div
                      initial={{ scaleX: 0 }}
                      animate={{ scaleX: 1 }}
                      className="absolute bottom-0 left-0 right-0 h-1 bg-gradient-to-r from-purple-500 to-pink-500 origin-left"
                    />
                  )}
                </Card>
              </motion.div>
            );
          })}
        </div>

        <motion.div
          initial={{ opacity: 0, y: 20 }}
          animate={{ opacity: 1, y: 0 }}
          transition={{ delay: 0.6 }}
          className="flex justify-center gap-4"
        >
          <Button
            variant="outline"
            onClick={() => navigate("/input")}
            className="bg-white/10 border-white/20 text-white hover:bg-white/20"
          >
            Back
          </Button>
          <Button
            onClick={handleContinue}
            disabled={selectedCareers.length < 2}
            size="lg"
            className="bg-gradient-to-r from-purple-600 to-pink-600 hover:from-purple-700 hover:to-pink-700 text-white px-8 py-6 text-lg rounded-full shadow-xl disabled:opacity-50 disabled:cursor-not-allowed"
          >
            Start Simulations ({selectedCareers.length} careers)
            <ArrowRight className="ml-2 h-5 w-5" />
          </Button>
        </motion.div>
      </div>
    </div>
  );
}
