import { useState, useEffect } from "react";
import { useNavigate, useParams } from "react-router";
import { motion, AnimatePresence } from "motion/react";
import { Button } from "../components/ui/button";
import { Progress } from "../components/ui/progress";
import { Badge } from "../components/ui/badge";
import {
  TrendingUp,
  TrendingDown,
  Calendar,
  DollarSign,
  Activity,
  Smile,
  Scale,
  Sparkles,
  FastForward,
} from "lucide-react";
import { careers } from "../data/careers";

export function Simulation() {
  const navigate = useNavigate();
  const { careerId } = useParams();
  const [currentYear, setCurrentYear] = useState(0);
  const [isPlaying, setIsPlaying] = useState(false);
  const [simulationComplete, setSimulationComplete] = useState(false);
  const [speed, setSpeed] = useState(1);

  const career = careers.find((c) => c.id === careerId);
  const selectedCareers = JSON.parse(
    sessionStorage.getItem("selectedCareers") || "[]"
  );
  const currentIndex = selectedCareers.indexOf(careerId);

  if (!career) {
    navigate("/careers");
    return null;
  }

  const currentTimeline = career.timeline[currentYear];

  useEffect(() => {
    if (isPlaying && currentYear < career.timeline.length - 1) {
      const timer = setTimeout(() => {
        setCurrentYear(currentYear + 1);
      }, 2000 / speed);
      return () => clearTimeout(timer);
    } else if (isPlaying && currentYear === career.timeline.length - 1) {
      setIsPlaying(false);
      setSimulationComplete(true);
    }
  }, [isPlaying, currentYear, career.timeline.length, speed]);

  const handleContinue = () => {
    // Check if there are more careers to simulate
    if (currentIndex < selectedCareers.length - 1) {
      navigate(`/simulation/${selectedCareers[currentIndex + 1]}`);
    } else {
      navigate("/comparison");
    }
  };

  const handleSkip = () => {
    setCurrentYear(career.timeline.length - 1);
    setIsPlaying(false);
    setSimulationComplete(true);
  };

  return (
    <div className="min-h-screen bg-gradient-to-br from-gray-900 via-blue-900 to-purple-900 text-white overflow-hidden">
      {/* VR-style overlay effect */}
      <div className="absolute inset-0 pointer-events-none">
        <div className="absolute inset-0 bg-[radial-gradient(circle_at_center,transparent_0%,rgba(0,0,0,0.4)_100%)]" />
        <motion.div
          animate={{
            opacity: [0.1, 0.2, 0.1],
          }}
          transition={{
            duration: 3,
            repeat: Infinity,
          }}
          className="absolute inset-0 bg-[linear-gradient(0deg,transparent_0%,rgba(59,130,246,0.1)_50%,transparent_100%)] bg-[length:100%_4px]"
        />
      </div>

      <div className="relative z-10 container mx-auto px-4 py-8 max-w-6xl">
        {/* Header */}
        <motion.div
          initial={{ opacity: 0, y: -20 }}
          animate={{ opacity: 1, y: 0 }}
          className="mb-6"
        >
          <div className="flex items-center justify-between mb-4">
            <div className="flex items-center gap-4">
              <div className="text-5xl">{career.icon}</div>
              <div>
                <h1 className="mb-1">{career.title}</h1>
                <p className="text-sm text-gray-300">
                  Experiencing career path {currentIndex + 1} of {selectedCareers.length}
                </p>
              </div>
            </div>
            <div className="text-right">
              <div className="text-3xl font-bold text-blue-400">
                Year {currentTimeline.year}
              </div>
              <p className="text-sm text-gray-400">of 5-year simulation</p>
            </div>
          </div>

          <Progress
            value={(currentYear / (career.timeline.length - 1)) * 100}
            className="h-2 bg-white/10"
          />
        </motion.div>

        {/* Main Simulation Area */}
        <div className="grid lg:grid-cols-3 gap-6 mb-6">
          {/* Left: Current Role & Events */}
          <div className="lg:col-span-2 space-y-6">
            <AnimatePresence mode="wait">
              <motion.div
                key={currentYear}
                initial={{ opacity: 0, x: -50, scale: 0.9 }}
                animate={{ opacity: 1, x: 0, scale: 1 }}
                exit={{ opacity: 0, x: 50, scale: 0.9 }}
                className="bg-gradient-to-br from-blue-600/30 to-purple-600/30 backdrop-blur-xl rounded-2xl p-8 border border-white/20 shadow-2xl"
              >
                <div className="flex items-center gap-3 mb-4">
                  <Calendar className="w-6 h-6 text-blue-300" />
                  <h2>Year {currentTimeline.year}</h2>
                </div>

                <div className="mb-6">
                  <Badge className="bg-purple-500/50 text-white text-lg px-4 py-1 mb-4">
                    {currentTimeline.role}
                  </Badge>
                  <div className="flex items-center gap-6 text-lg">
                    <div className="flex items-center gap-2">
                      <DollarSign className="w-5 h-5 text-green-400" />
                      <span className="font-semibold">
                        ${currentTimeline.salary.toLocaleString()}
                      </span>
                    </div>
                  </div>
                </div>

                <div className="space-y-3">
                  <h3 className="text-lg font-semibold flex items-center gap-2">
                    <Sparkles className="w-5 h-5 text-yellow-400" />
                    Key Events This Year
                  </h3>
                  {currentTimeline.events.map((event, i) => (
                    <motion.div
                      key={i}
                      initial={{ opacity: 0, x: -20 }}
                      animate={{ opacity: 1, x: 0 }}
                      transition={{ delay: i * 0.2 }}
                      className="flex items-start gap-3 bg-white/10 rounded-lg p-3 border border-white/20"
                    >
                      <div className="w-2 h-2 bg-green-400 rounded-full mt-2 flex-shrink-0" />
                      <p className="text-gray-200">{event}</p>
                    </motion.div>
                  ))}
                </div>
              </motion.div>
            </AnimatePresence>

            {/* Daily Tasks Preview */}
            <motion.div
              initial={{ opacity: 0, y: 20 }}
              animate={{ opacity: 1, y: 0 }}
              transition={{ delay: 0.3 }}
              className="bg-white/10 backdrop-blur-lg rounded-xl p-6 border border-white/20"
            >
              <h3 className="font-semibold mb-3">Daily Tasks in This Role:</h3>
              <div className="space-y-2">
                {career.dailyTasks.slice(0, 3).map((task, i) => (
                  <div key={i} className="flex items-center gap-2 text-sm text-gray-300">
                    <div className="w-1.5 h-1.5 bg-blue-400 rounded-full" />
                    {task}
                  </div>
                ))}
              </div>
            </motion.div>
          </div>

          {/* Right: Metrics */}
          <div className="space-y-4">
            <AnimatePresence mode="wait">
              <motion.div
                key={`metrics-${currentYear}`}
                initial={{ opacity: 0, scale: 0.9 }}
                animate={{ opacity: 1, scale: 1 }}
                exit={{ opacity: 0, scale: 0.9 }}
                className="space-y-4"
              >
                {/* Stress Level */}
                <div className="bg-white/10 backdrop-blur-lg rounded-xl p-5 border border-white/20">
                  <div className="flex items-center justify-between mb-3">
                    <div className="flex items-center gap-2">
                      <Activity className="w-5 h-5 text-red-400" />
                      <span className="font-semibold">Stress Level</span>
                    </div>
                    <span className="text-2xl font-bold">{currentTimeline.stress}%</span>
                  </div>
                  <Progress
                    value={currentTimeline.stress}
                    className="h-3 bg-white/20"
                  />
                  <div className="flex justify-between text-xs text-gray-400 mt-1">
                    <span>Low</span>
                    <span>High</span>
                  </div>
                </div>

                {/* Satisfaction */}
                <div className="bg-white/10 backdrop-blur-lg rounded-xl p-5 border border-white/20">
                  <div className="flex items-center justify-between mb-3">
                    <div className="flex items-center gap-2">
                      <Smile className="w-5 h-5 text-green-400" />
                      <span className="font-semibold">Satisfaction</span>
                    </div>
                    <span className="text-2xl font-bold">
                      {currentTimeline.satisfaction}%
                    </span>
                  </div>
                  <Progress
                    value={currentTimeline.satisfaction}
                    className="h-3 bg-white/20"
                  />
                  <div className="flex justify-between text-xs text-gray-400 mt-1">
                    <span>Low</span>
                    <span>High</span>
                  </div>
                </div>

                {/* Work-Life Balance */}
                <div className="bg-white/10 backdrop-blur-lg rounded-xl p-5 border border-white/20">
                  <div className="flex items-center justify-between mb-3">
                    <div className="flex items-center gap-2">
                      <Scale className="w-5 h-5 text-blue-400" />
                      <span className="font-semibold">Work-Life Balance</span>
                    </div>
                    <span className="text-2xl font-bold">
                      {currentTimeline.workLifeBalance}%
                    </span>
                  </div>
                  <Progress
                    value={currentTimeline.workLifeBalance}
                    className="h-3 bg-white/20"
                  />
                  <div className="flex justify-between text-xs text-gray-400 mt-1">
                    <span>Poor</span>
                    <span>Great</span>
                  </div>
                </div>

                {/* Salary Trend */}
                <div className="bg-white/10 backdrop-blur-lg rounded-xl p-5 border border-white/20">
                  <div className="flex items-center gap-2 mb-2">
                    {currentYear > 0 &&
                    currentTimeline.salary > career.timeline[currentYear - 1].salary ? (
                      <TrendingUp className="w-5 h-5 text-green-400" />
                    ) : currentYear > 0 ? (
                      <TrendingDown className="w-5 h-5 text-red-400" />
                    ) : (
                      <DollarSign className="w-5 h-5 text-blue-400" />
                    )}
                    <span className="font-semibold">Salary Progression</span>
                  </div>
                  {currentYear > 0 && (
                    <p className="text-sm text-gray-300">
                      {currentTimeline.salary > career.timeline[currentYear - 1].salary
                        ? `+$${(
                            currentTimeline.salary - career.timeline[currentYear - 1].salary
                          ).toLocaleString()} from last year`
                        : "No change from last year"}
                    </p>
                  )}
                </div>
              </motion.div>
            </AnimatePresence>
          </div>
        </div>

        {/* Controls */}
        <motion.div
          initial={{ opacity: 0, y: 20 }}
          animate={{ opacity: 1, y: 0 }}
          transition={{ delay: 0.5 }}
          className="flex items-center justify-center gap-4"
        >
          {!simulationComplete ? (
            <>
              <Button
                onClick={() => setIsPlaying(!isPlaying)}
                size="lg"
                className="bg-gradient-to-r from-blue-600 to-purple-600 hover:from-blue-700 hover:to-purple-700 text-white px-8"
              >
                {isPlaying ? "Pause" : "Play"} Simulation
              </Button>
              <Button
                onClick={handleSkip}
                variant="outline"
                className="bg-white/10 border-white/20 text-white hover:bg-white/20"
              >
                <FastForward className="mr-2 h-4 w-4" />
                Skip to End
              </Button>
              <select
                value={speed}
                onChange={(e) => setSpeed(Number(e.target.value))}
                className="bg-white/10 border border-white/20 rounded-lg px-4 py-2 text-white"
              >
                <option value={0.5}>0.5x</option>
                <option value={1}>1x</option>
                <option value={2}>2x</option>
                <option value={3}>3x</option>
              </select>
            </>
          ) : (
            <Button
              onClick={handleContinue}
              size="lg"
              className="bg-gradient-to-r from-green-600 to-emerald-600 hover:from-green-700 hover:to-emerald-700 text-white px-8"
            >
              {currentIndex < selectedCareers.length - 1
                ? `Continue to Next Career (${currentIndex + 2}/${selectedCareers.length})`
                : "Compare All Careers"}
            </Button>
          )}
        </motion.div>
      </div>
    </div>
  );
}
