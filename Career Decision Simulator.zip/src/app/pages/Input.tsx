import { useState } from "react";
import { useNavigate } from "react-router";
import { motion } from "motion/react";
import { Button } from "../components/ui/button";
import { Card } from "../components/ui/card";
import { Label } from "../components/ui/label";
import { Checkbox } from "../components/ui/checkbox";
import { Slider } from "../components/ui/slider";
import { ArrowRight, User, Lightbulb, Heart, TrendingUp, Home } from "lucide-react";

export function Input() {
  const navigate = useNavigate();
  const [profile, setProfile] = useState({
    interests: [] as string[],
    skills: [] as string[],
    personality: [] as string[],
    riskTolerance: 50,
    workLifePreference: 50,
  });

  const interestOptions = [
    "Technology & Coding",
    "Business & Entrepreneurship",
    "Design & Creativity",
    "Data & Analytics",
    "Marketing & Communication",
    "Leadership & Management",
  ];

  const skillOptions = [
    "Problem Solving",
    "Logical Thinking",
    "Creativity",
    "Communication",
    "Analytical Skills",
    "Leadership",
    "Technical Skills",
    "Empathy",
  ];

  const personalityOptions = [
    "Risk-Taker",
    "Stable & Steady",
    "Team Player",
    "Independent Worker",
    "Detail-Oriented",
    "Big Picture Thinker",
  ];

  const toggleItem = (category: keyof typeof profile, item: string) => {
    const current = profile[category] as string[];
    if (current.includes(item)) {
      setProfile({ ...profile, [category]: current.filter((i) => i !== item) });
    } else {
      setProfile({ ...profile, [category]: [...current, item] });
    }
  };

  const handleSubmit = () => {
    // Store profile in sessionStorage
    sessionStorage.setItem("userProfile", JSON.stringify(profile));
    navigate("/careers");
  };

  const isValid =
    profile.interests.length > 0 &&
    profile.skills.length > 0 &&
    profile.personality.length > 0;

  return (
    <div className="min-h-screen bg-gradient-to-br from-indigo-900 via-purple-900 to-pink-900 text-white">
      <div className="container mx-auto px-4 py-12 max-w-4xl">
        <motion.div
          initial={{ opacity: 0, y: -20 }}
          animate={{ opacity: 1, y: 0 }}
          className="mb-8"
        >
          <Button
            variant="ghost"
            onClick={() => navigate("/")}
            className="mb-4 text-white hover:bg-white/10"
          >
            <Home className="mr-2 h-4 w-4" />
            Back to Home
          </Button>

          <div className="flex items-center gap-4 mb-6">
            <div className="w-12 h-12 bg-gradient-to-br from-purple-500 to-pink-500 rounded-full flex items-center justify-center">
              <User className="w-6 h-6" />
            </div>
            <div>
              <h1 className="mb-2">Step 1: Tell Us About You</h1>
              <p className="text-gray-300">
                Help us understand your unique profile to recommend the best careers
              </p>
            </div>
          </div>
        </motion.div>

        <div className="space-y-6">
          {/* Interests */}
          <motion.div
            initial={{ opacity: 0, x: -20 }}
            animate={{ opacity: 1, x: 0 }}
            transition={{ delay: 0.1 }}
          >
            <Card className="bg-white/10 backdrop-blur-lg border-white/20 p-6">
              <div className="flex items-center gap-3 mb-4">
                <Lightbulb className="w-6 h-6 text-yellow-400" />
                <Label className="text-xl font-semibold text-white">
                  What are your interests?
                </Label>
              </div>
              <p className="text-sm text-gray-300 mb-4">Select all that apply</p>
              <div className="grid md:grid-cols-2 gap-3">
                {interestOptions.map((interest) => (
                  <div
                    key={interest}
                    className={`flex items-center space-x-3 p-3 rounded-lg border-2 transition-all cursor-pointer ${
                      profile.interests.includes(interest)
                        ? "bg-purple-500/30 border-purple-400"
                        : "bg-white/5 border-white/10 hover:border-white/30"
                    }`}
                    onClick={() => toggleItem("interests", interest)}
                  >
                    <Checkbox
                      checked={profile.interests.includes(interest)}
                      onCheckedChange={() => toggleItem("interests", interest)}
                    />
                    <span className="text-white">{interest}</span>
                  </div>
                ))}
              </div>
            </Card>
          </motion.div>

          {/* Skills */}
          <motion.div
            initial={{ opacity: 0, x: -20 }}
            animate={{ opacity: 1, x: 0 }}
            transition={{ delay: 0.2 }}
          >
            <Card className="bg-white/10 backdrop-blur-lg border-white/20 p-6">
              <div className="flex items-center gap-3 mb-4">
                <TrendingUp className="w-6 h-6 text-green-400" />
                <Label className="text-xl font-semibold text-white">
                  What are your strengths?
                </Label>
              </div>
              <p className="text-sm text-gray-300 mb-4">Select your top skills</p>
              <div className="grid md:grid-cols-2 gap-3">
                {skillOptions.map((skill) => (
                  <div
                    key={skill}
                    className={`flex items-center space-x-3 p-3 rounded-lg border-2 transition-all cursor-pointer ${
                      profile.skills.includes(skill)
                        ? "bg-green-500/30 border-green-400"
                        : "bg-white/5 border-white/10 hover:border-white/30"
                    }`}
                    onClick={() => toggleItem("skills", skill)}
                  >
                    <Checkbox
                      checked={profile.skills.includes(skill)}
                      onCheckedChange={() => toggleItem("skills", skill)}
                    />
                    <span className="text-white">{skill}</span>
                  </div>
                ))}
              </div>
            </Card>
          </motion.div>

          {/* Personality */}
          <motion.div
            initial={{ opacity: 0, x: -20 }}
            animate={{ opacity: 1, x: 0 }}
            transition={{ delay: 0.3 }}
          >
            <Card className="bg-white/10 backdrop-blur-lg border-white/20 p-6">
              <div className="flex items-center gap-3 mb-4">
                <Heart className="w-6 h-6 text-pink-400" />
                <Label className="text-xl font-semibold text-white">
                  What describes you best?
                </Label>
              </div>
              <p className="text-sm text-gray-300 mb-4">Select your personality traits</p>
              <div className="grid md:grid-cols-2 gap-3">
                {personalityOptions.map((trait) => (
                  <div
                    key={trait}
                    className={`flex items-center space-x-3 p-3 rounded-lg border-2 transition-all cursor-pointer ${
                      profile.personality.includes(trait)
                        ? "bg-pink-500/30 border-pink-400"
                        : "bg-white/5 border-white/10 hover:border-white/30"
                    }`}
                    onClick={() => toggleItem("personality", trait)}
                  >
                    <Checkbox
                      checked={profile.personality.includes(trait)}
                      onCheckedChange={() => toggleItem("personality", trait)}
                    />
                    <span className="text-white">{trait}</span>
                  </div>
                ))}
              </div>
            </Card>
          </motion.div>

          {/* Risk Tolerance */}
          <motion.div
            initial={{ opacity: 0, x: -20 }}
            animate={{ opacity: 1, x: 0 }}
            transition={{ delay: 0.4 }}
          >
            <Card className="bg-white/10 backdrop-blur-lg border-white/20 p-6">
              <Label className="text-xl font-semibold text-white mb-2 block">
                Risk Tolerance
              </Label>
              <p className="text-sm text-gray-300 mb-4">
                How comfortable are you with career uncertainty?
              </p>
              <div className="space-y-4">
                <Slider
                  value={[profile.riskTolerance]}
                  onValueChange={(value) =>
                    setProfile({ ...profile, riskTolerance: value[0] })
                  }
                  max={100}
                  step={1}
                  className="w-full"
                />
                <div className="flex justify-between text-sm">
                  <span className="text-blue-300">Stable & Secure</span>
                  <span className="text-white font-semibold">{profile.riskTolerance}%</span>
                  <span className="text-orange-300">High Risk, High Reward</span>
                </div>
              </div>
            </Card>
          </motion.div>

          {/* Work-Life Balance Preference */}
          <motion.div
            initial={{ opacity: 0, x: -20 }}
            animate={{ opacity: 1, x: 0 }}
            transition={{ delay: 0.5 }}
          >
            <Card className="bg-white/10 backdrop-blur-lg border-white/20 p-6">
              <Label className="text-xl font-semibold text-white mb-2 block">
                Work-Life Balance Preference
              </Label>
              <p className="text-sm text-gray-300 mb-4">
                What's more important to you?
              </p>
              <div className="space-y-4">
                <Slider
                  value={[profile.workLifePreference]}
                  onValueChange={(value) =>
                    setProfile({ ...profile, workLifePreference: value[0] })
                  }
                  max={100}
                  step={1}
                  className="w-full"
                />
                <div className="flex justify-between text-sm">
                  <span className="text-green-300">Work-Life Balance</span>
                  <span className="text-white font-semibold">
                    {profile.workLifePreference}%
                  </span>
                  <span className="text-yellow-300">Career Growth</span>
                </div>
              </div>
            </Card>
          </motion.div>
        </div>

        <motion.div
          initial={{ opacity: 0, y: 20 }}
          animate={{ opacity: 1, y: 0 }}
          transition={{ delay: 0.6 }}
          className="mt-8 flex justify-center"
        >
          <Button
            onClick={handleSubmit}
            disabled={!isValid}
            size="lg"
            className="bg-gradient-to-r from-purple-600 to-pink-600 hover:from-purple-700 hover:to-pink-700 text-white px-8 py-6 text-lg rounded-full shadow-xl disabled:opacity-50 disabled:cursor-not-allowed"
          >
            Continue to Career Selection
            <ArrowRight className="ml-2 h-5 w-5" />
          </Button>
        </motion.div>
      </div>
    </div>
  );
}
