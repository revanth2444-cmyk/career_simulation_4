import { useNavigate } from "react-router";
import { motion } from "motion/react";
import { Button } from "../components/ui/button";
import { Sparkles, TrendingUp, Target, Brain } from "lucide-react";
import { InstallPrompt } from "../components/InstallPrompt";

export function Home() {
  const navigate = useNavigate();

  return (
    <div className="min-h-screen bg-gradient-to-br from-purple-900 via-blue-900 to-indigo-900 text-white overflow-hidden">
      <InstallPrompt />
      {/* Animated background elements */}
      <div className="absolute inset-0 overflow-hidden pointer-events-none">
        {[...Array(20)].map((_, i) => (
          <motion.div
            key={i}
            className="absolute w-2 h-2 bg-white rounded-full opacity-20"
            animate={{
              y: [0, -1000],
              x: [0, Math.random() * 100 - 50],
              opacity: [0, 0.5, 0],
            }}
            transition={{
              duration: Math.random() * 3 + 2,
              repeat: Infinity,
              delay: Math.random() * 2,
            }}
            style={{
              left: `${Math.random() * 100}%`,
              top: "100%",
            }}
          />
        ))}
      </div>

      <div className="relative z-10 container mx-auto px-4 py-16 max-w-6xl">
        {/* Header */}
        <motion.div
          initial={{ opacity: 0, y: -20 }}
          animate={{ opacity: 1, y: 0 }}
          transition={{ duration: 0.6 }}
          className="text-center mb-16"
        >
          <motion.div
            initial={{ scale: 0 }}
            animate={{ scale: 1 }}
            transition={{ delay: 0.2, type: "spring" }}
            className="inline-block mb-6"
          >
            <div className="relative">
              <Sparkles className="w-20 h-20 text-yellow-400 mx-auto" />
              <motion.div
                animate={{ rotate: 360 }}
                transition={{ duration: 20, repeat: Infinity, ease: "linear" }}
                className="absolute inset-0"
              >
                <div className="w-full h-full border-4 border-dashed border-purple-400/30 rounded-full" />
              </motion.div>
            </div>
          </motion.div>

          <motion.h1
            initial={{ opacity: 0, y: 20 }}
            animate={{ opacity: 1, y: 0 }}
            transition={{ delay: 0.3 }}
            className="mb-4"
          >
            Reality Forking: Career Decision Simulator
          </motion.h1>

          <motion.p
            initial={{ opacity: 0 }}
            animate={{ opacity: 1 }}
            transition={{ delay: 0.4 }}
            className="text-xl text-blue-200 mb-8"
          >
            "Don't choose your future blindly—experience it first."
          </motion.p>
        </motion.div>

        {/* Problem Section */}
        <motion.section
          initial={{ opacity: 0, x: -50 }}
          animate={{ opacity: 1, x: 0 }}
          transition={{ delay: 0.5 }}
          className="mb-16 bg-white/10 backdrop-blur-lg rounded-2xl p-8 border border-white/20"
        >
          <div className="flex items-start gap-4 mb-4">
            <div className="w-12 h-12 bg-red-500 rounded-lg flex items-center justify-center flex-shrink-0">
              <Target className="w-6 h-6" />
            </div>
            <div>
              <h2 className="mb-4">🚀 The Problem</h2>
              <p className="text-lg text-gray-200 mb-6">
                Today, students choose careers based on:
              </p>
              <ul className="space-y-3 text-gray-200">
                <li className="flex items-center gap-3">
                  <span className="w-2 h-2 bg-red-400 rounded-full" />
                  Guesswork and limited information
                </li>
                <li className="flex items-center gap-3">
                  <span className="w-2 h-2 bg-red-400 rounded-full" />
                  Peer pressure and family expectations
                </li>
                <li className="flex items-center gap-3">
                  <span className="w-2 h-2 bg-red-400 rounded-full" />
                  Limited real-world exposure
                </li>
              </ul>
              <div className="mt-6 p-4 bg-red-900/30 rounded-lg border border-red-500/30">
                <p className="text-red-200">
                  <strong>Result:</strong> Wrong career choices → Stress & burnout → Wasted years
                </p>
              </div>
            </div>
          </div>
        </motion.section>

        {/* Solution Section */}
        <motion.section
          initial={{ opacity: 0, x: 50 }}
          animate={{ opacity: 1, x: 0 }}
          transition={{ delay: 0.7 }}
          className="mb-16 bg-white/10 backdrop-blur-lg rounded-2xl p-8 border border-white/20"
        >
          <div className="flex items-start gap-4 mb-4">
            <div className="w-12 h-12 bg-green-500 rounded-lg flex items-center justify-center flex-shrink-0">
              <Brain className="w-6 h-6" />
            </div>
            <div className="flex-1">
              <h2 className="mb-4">💡 The Solution</h2>
              <p className="text-lg text-gray-200 mb-6">
                A simulation-based system where you can:
              </p>
              <div className="grid md:grid-cols-2 gap-4">
                <div className="p-4 bg-gradient-to-br from-green-900/40 to-emerald-900/40 rounded-xl border border-green-500/30">
                  <p className="font-semibold mb-2">👉 Experience Different Careers</p>
                  <p className="text-sm text-gray-300">Live through years of experience in minutes</p>
                </div>
                <div className="p-4 bg-gradient-to-br from-blue-900/40 to-cyan-900/40 rounded-xl border border-blue-500/30">
                  <p className="font-semibold mb-2">👉 Compare Outcomes</p>
                  <p className="text-sm text-gray-300">See salary, stress, satisfaction & more</p>
                </div>
                <div className="p-4 bg-gradient-to-br from-purple-900/40 to-pink-900/40 rounded-xl border border-purple-500/30">
                  <p className="font-semibold mb-2">👉 Make Informed Decisions</p>
                  <p className="text-sm text-gray-300">Choose with confidence, not guesswork</p>
                </div>
                <div className="p-4 bg-gradient-to-br from-orange-900/40 to-yellow-900/40 rounded-xl border border-orange-500/30">
                  <p className="font-semibold mb-2">👉 Timeline Acceleration</p>
                  <p className="text-sm text-gray-300">5 years compressed into 10 minutes</p>
                </div>
              </div>
            </div>
          </div>
        </motion.section>

        {/* How It Works */}
        <motion.section
          initial={{ opacity: 0, y: 30 }}
          animate={{ opacity: 1, y: 0 }}
          transition={{ delay: 0.9 }}
          className="mb-16"
        >
          <h2 className="text-center mb-8">🌍 How It Works</h2>
          <div className="grid md:grid-cols-5 gap-4">
            {[
              { step: "1", title: "Input", desc: "Your profile" },
              { step: "2", title: "Select", desc: "2-3 careers" },
              { step: "3", title: "Simulate", desc: "Experience years" },
              { step: "4", title: "Compare", desc: "Analyze data" },
              { step: "5", title: "Decide", desc: "Choose wisely" },
            ].map((item, i) => (
              <motion.div
                key={i}
                initial={{ opacity: 0, scale: 0.8 }}
                animate={{ opacity: 1, scale: 1 }}
                transition={{ delay: 1 + i * 0.1 }}
                className="relative"
              >
                <div className="bg-gradient-to-br from-indigo-900/60 to-purple-900/60 backdrop-blur-sm rounded-xl p-6 border border-indigo-500/30 text-center">
                  <div className="w-12 h-12 bg-gradient-to-br from-yellow-400 to-orange-500 rounded-full flex items-center justify-center mx-auto mb-3 text-xl font-bold text-black">
                    {item.step}
                  </div>
                  <h3 className="font-semibold mb-1">{item.title}</h3>
                  <p className="text-sm text-gray-300">{item.desc}</p>
                </div>
                {i < 4 && (
                  <div className="hidden md:block absolute top-1/2 -right-2 w-4 h-0.5 bg-gradient-to-r from-indigo-500 to-transparent" />
                )}
              </motion.div>
            ))}
          </div>
        </motion.section>

        {/* Unique Value */}
        <motion.section
          initial={{ opacity: 0, scale: 0.9 }}
          animate={{ opacity: 1, scale: 1 }}
          transition={{ delay: 1.2 }}
          className="mb-16 bg-gradient-to-r from-yellow-900/40 to-orange-900/40 backdrop-blur-lg rounded-2xl p-8 border border-yellow-500/40"
        >
          <div className="flex items-center gap-4 mb-4">
            <TrendingUp className="w-10 h-10 text-yellow-400" />
            <div>
              <h2 className="mb-2">🤯 What Makes This Unique</h2>
              <p className="text-lg text-gray-200">
                This is NOT career counseling or online courses.
              </p>
              <p className="text-xl font-semibold text-yellow-300 mt-2">
                This IS: Experience-based decision making
              </p>
              <p className="text-gray-200 mt-4">
                🔥 <strong>Key Innovation:</strong> "Timeline Acceleration + AI Simulation"
              </p>
              <p className="text-gray-300 mt-2">
                Live multiple careers before choosing one — that's your edge.
              </p>
            </div>
          </div>
        </motion.section>

        {/* Impact */}
        <motion.section
          initial={{ opacity: 0, y: 30 }}
          animate={{ opacity: 1, y: 0 }}
          transition={{ delay: 1.4 }}
          className="mb-12 text-center"
        >
          <h2 className="mb-6">🎯 Real-World Impact</h2>
          <div className="grid md:grid-cols-3 gap-6">
            <div className="bg-white/10 backdrop-blur-sm rounded-xl p-6 border border-white/20">
              <div className="text-4xl mb-3">✓</div>
              <p className="font-semibold mb-2">Reduces Wrong Choices</p>
              <p className="text-sm text-gray-300">Data-driven decisions</p>
            </div>
            <div className="bg-white/10 backdrop-blur-sm rounded-xl p-6 border border-white/20">
              <div className="text-4xl mb-3">⏰</div>
              <p className="font-semibold mb-2">Saves Time & Money</p>
              <p className="text-sm text-gray-300">No wasted years</p>
            </div>
            <div className="bg-white/10 backdrop-blur-sm rounded-xl p-6 border border-white/20">
              <div className="text-4xl mb-3">😊</div>
              <p className="font-semibold mb-2">Improves Satisfaction</p>
              <p className="text-sm text-gray-300">Find your true calling</p>
            </div>
          </div>
        </motion.section>

        {/* CTA */}
        <motion.div
          initial={{ opacity: 0, y: 20 }}
          animate={{ opacity: 1, y: 0 }}
          transition={{ delay: 1.6 }}
          className="text-center"
        >
          <Button
            onClick={() => navigate("/input")}
            size="lg"
            className="bg-gradient-to-r from-purple-600 to-pink-600 hover:from-purple-700 hover:to-pink-700 text-white px-12 py-6 text-xl rounded-full shadow-2xl hover:shadow-purple-500/50 transition-all duration-300 transform hover:scale-105"
          >
            <Sparkles className="mr-2 h-6 w-6" />
            Start Your Journey
          </Button>
          <p className="mt-4 text-gray-300">Experience your future in the next 15 minutes</p>
        </motion.div>
      </div>
    </div>
  );
}