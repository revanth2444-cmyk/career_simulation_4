import { useState } from "react";
import { useNavigate } from "react-router";
import { motion } from "motion/react";
import { Button } from "../components/ui/button";
import { Card } from "../components/ui/card";
import { Badge } from "../components/ui/badge";
import {
  CheckCircle2,
  TrendingUp,
  AlertCircle,
  Sparkles,
  Home,
  RefreshCw,
} from "lucide-react";
import { careers } from "../data/careers";
import confetti from "canvas-confetti";

export function Decision() {
  const navigate = useNavigate();
  const [selectedCareer, setSelectedCareer] = useState<string | null>(null);
  const [showConfetti, setShowConfetti] = useState(false);

  const selectedCareerIds = JSON.parse(
    sessionStorage.getItem("selectedCareers") || "[]"
  );
  const selectedCareers = careers.filter((c) => selectedCareerIds.includes(c.id));

  const handleSelectCareer = (careerId: string) => {
    setSelectedCareer(careerId);
    setShowConfetti(true);

    // Trigger confetti
    const duration = 3000;
    const end = Date.now() + duration;

    const colors = ["#8b5cf6", "#ec4899", "#06b6d4", "#10b981"];

    (function frame() {
      confetti({
        particleCount: 3,
        angle: 60,
        spread: 55,
        origin: { x: 0 },
        colors: colors,
      });
      confetti({
        particleCount: 3,
        angle: 120,
        spread: 55,
        origin: { x: 1 },
        colors: colors,
      });

      if (Date.now() < end) {
        requestAnimationFrame(frame);
      }
    })();
  };

  const chosenCareer = selectedCareers.find((c) => c.id === selectedCareer);

  return (
    <div className="min-h-screen bg-gradient-to-br from-purple-900 via-indigo-900 to-blue-900 text-white">
      <div className="container mx-auto px-4 py-12 max-w-6xl">
        <motion.div
          initial={{ opacity: 0, y: -20 }}
          animate={{ opacity: 1, y: 0 }}
          className="mb-8 text-center"
        >
          <h1 className="mb-4">Step 5: Make Your Decision</h1>
          <p className="text-xl text-gray-300">
            {selectedCareer
              ? "Congratulations! You've made an informed decision."
              : "Based on your experiences, which career path feels right for you?"}
          </p>
        </motion.div>

        {!selectedCareer ? (
          <>
            {/* Career Cards */}
            <div className="grid md:grid-cols-3 gap-6 mb-8">
              {selectedCareers.map((career, index) => (
                <motion.div
                  key={career.id}
                  initial={{ opacity: 0, scale: 0.9 }}
                  animate={{ opacity: 1, scale: 1 }}
                  transition={{ delay: index * 0.1 }}
                >
                  <Card
                    className="bg-white/10 backdrop-blur-lg border-white/20 p-6 cursor-pointer hover:border-purple-400 transition-all hover:shadow-2xl hover:shadow-purple-500/20 h-full"
                    onClick={() => handleSelectCareer(career.id)}
                  >
                    <div className="text-center mb-4">
                      <div className="text-5xl mb-3">{career.icon}</div>
                      <h3 className="font-semibold text-white mb-2">{career.title}</h3>
                    </div>

                    <div className="space-y-3">
                      <div className="flex items-center justify-between text-sm bg-white/5 rounded p-2">
                        <span className="text-gray-300">Avg Salary</span>
                        <span className="font-semibold text-green-400">
                          ${(career.finalMetrics.avgSalary / 1000).toFixed(0)}K
                        </span>
                      </div>
                      <div className="flex items-center justify-between text-sm bg-white/5 rounded p-2">
                        <span className="text-gray-300">Risk</span>
                        <span
                          className={`font-semibold ${
                            career.finalMetrics.riskLevel > 70
                              ? "text-red-400"
                              : career.finalMetrics.riskLevel > 40
                              ? "text-yellow-400"
                              : "text-green-400"
                          }`}
                        >
                          {career.finalMetrics.riskLevel}%
                        </span>
                      </div>
                      <div className="flex items-center justify-between text-sm bg-white/5 rounded p-2">
                        <span className="text-gray-300">Satisfaction</span>
                        <span className="font-semibold text-blue-400">
                          {career.finalMetrics.satisfaction}%
                        </span>
                      </div>
                      <div className="flex items-center justify-between text-sm bg-white/5 rounded p-2">
                        <span className="text-gray-300">Work-Life</span>
                        <span className="font-semibold text-purple-400">
                          {career.finalMetrics.workLifeBalance}%
                        </span>
                      </div>
                    </div>

                    <Button className="w-full mt-4 bg-gradient-to-r from-purple-600 to-pink-600 hover:from-purple-700 hover:to-pink-700">
                      Choose This Path
                    </Button>
                  </Card>
                </motion.div>
              ))}
            </div>

            {/* Decision Helper */}
            <motion.div
              initial={{ opacity: 0, y: 20 }}
              animate={{ opacity: 1, y: 0 }}
              transition={{ delay: 0.4 }}
            >
              <Card className="bg-gradient-to-br from-blue-900/40 to-purple-900/40 backdrop-blur-lg border-blue-400/30 p-6">
                <div className="flex items-start gap-4">
                  <AlertCircle className="w-6 h-6 text-blue-400 flex-shrink-0 mt-1" />
                  <div>
                    <h3 className="font-semibold text-white mb-2">Need Help Deciding?</h3>
                    <p className="text-gray-300 mb-4">Consider these questions:</p>
                    <ul className="space-y-2 text-sm text-gray-300">
                      <li className="flex items-start gap-2">
                        <span className="text-blue-400 mt-1">•</span>
                        <span>
                          Which career path made you feel most excited during the simulation?
                        </span>
                      </li>
                      <li className="flex items-start gap-2">
                        <span className="text-blue-400 mt-1">•</span>
                        <span>
                          Are you willing to accept higher risk for potentially greater rewards?
                        </span>
                      </li>
                      <li className="flex items-start gap-2">
                        <span className="text-blue-400 mt-1">•</span>
                        <span>
                          How important is work-life balance vs. career growth to you?
                        </span>
                      </li>
                      <li className="flex items-start gap-2">
                        <span className="text-blue-400 mt-1">•</span>
                        <span>
                          Which daily tasks resonated most with your interests and strengths?
                        </span>
                      </li>
                    </ul>
                  </div>
                </div>
              </Card>
            </motion.div>
          </>
        ) : (
          <>
            {/* Success Message */}
            <motion.div
              initial={{ opacity: 0, scale: 0.8 }}
              animate={{ opacity: 1, scale: 1 }}
              className="text-center mb-8"
            >
              <motion.div
                initial={{ scale: 0 }}
                animate={{ scale: 1 }}
                transition={{ delay: 0.2, type: "spring" }}
                className="inline-block mb-6"
              >
                <CheckCircle2 className="w-24 h-24 text-green-400 mx-auto" />
              </motion.div>
              <motion.h2
                initial={{ opacity: 0, y: 20 }}
                animate={{ opacity: 1, y: 0 }}
                transition={{ delay: 0.3 }}
                className="mb-4"
              >
                You've Chosen: {chosenCareer?.title} {chosenCareer?.icon}
              </motion.h2>
              <motion.p
                initial={{ opacity: 0 }}
                animate={{ opacity: 1 }}
                transition={{ delay: 0.4 }}
                className="text-xl text-gray-300 mb-8"
              >
                Congratulations on making an informed, data-driven decision!
              </motion.p>
            </motion.div>

            {/* Career Summary */}
            <motion.div
              initial={{ opacity: 0, y: 20 }}
              animate={{ opacity: 1, y: 0 }}
              transition={{ delay: 0.5 }}
              className="max-w-3xl mx-auto mb-8"
            >
              <Card className="bg-gradient-to-br from-purple-600/30 to-pink-600/30 backdrop-blur-xl border-purple-400/40 p-8">
                <div className="flex items-center gap-4 mb-6">
                  <div className="text-6xl">{chosenCareer?.icon}</div>
                  <div>
                    <h3 className="text-2xl font-semibold text-white mb-2">
                      {chosenCareer?.title}
                    </h3>
                    <p className="text-gray-200">{chosenCareer?.description}</p>
                  </div>
                </div>

                <div className="grid md:grid-cols-2 gap-4 mb-6">
                  <div className="bg-white/10 rounded-lg p-4">
                    <div className="flex items-center gap-2 mb-2">
                      <TrendingUp className="w-5 h-5 text-green-400" />
                      <span className="font-semibold">Financial Outlook</span>
                    </div>
                    <p className="text-2xl font-bold text-green-400">
                      ${((chosenCareer?.finalMetrics.avgSalary ?? 0) / 1000).toFixed(0)}K avg
                    </p>
                    <p className="text-sm text-gray-300">Average annual salary</p>
                  </div>

                  <div className="bg-white/10 rounded-lg p-4">
                    <div className="flex items-center gap-2 mb-2">
                      <Sparkles className="w-5 h-5 text-yellow-400" />
                      <span className="font-semibold">Growth Potential</span>
                    </div>
                    <p className="text-2xl font-bold text-yellow-400">
                      {chosenCareer?.finalMetrics.growthPotential}%
                    </p>
                    <p className="text-sm text-gray-300">Career advancement opportunity</p>
                  </div>
                </div>

                <div className="space-y-3">
                  <div>
                    <h4 className="font-semibold mb-2 flex items-center gap-2">
                      <Sparkles className="w-4 h-4 text-purple-400" />
                      Key Skills You'll Develop:
                    </h4>
                    <div className="flex flex-wrap gap-2">
                      {chosenCareer?.skills.map((skill) => (
                        <Badge
                          key={skill}
                          className="bg-purple-500/30 text-white border-purple-400/30"
                        >
                          {skill}
                        </Badge>
                      ))}
                    </div>
                  </div>

                  <div>
                    <h4 className="font-semibold mb-2">What to Expect:</h4>
                    <div className="grid md:grid-cols-2 gap-3 text-sm">
                      <div className="flex items-center gap-2">
                        <div className="w-2 h-2 bg-green-400 rounded-full" />
                        <span className="text-gray-300">
                          {chosenCareer?.finalMetrics.satisfaction}% Job Satisfaction
                        </span>
                      </div>
                      <div className="flex items-center gap-2">
                        <div className="w-2 h-2 bg-blue-400 rounded-full" />
                        <span className="text-gray-300">
                          {chosenCareer?.finalMetrics.workLifeBalance}% Work-Life Balance
                        </span>
                      </div>
                      <div className="flex items-center gap-2">
                        <div
                          className={`w-2 h-2 rounded-full ${
                            (chosenCareer?.finalMetrics.riskLevel ?? 0) > 70
                              ? "bg-red-400"
                              : (chosenCareer?.finalMetrics.riskLevel ?? 0) > 40
                              ? "bg-yellow-400"
                              : "bg-green-400"
                          }`}
                        />
                        <span className="text-gray-300">
                          {chosenCareer?.finalMetrics.riskLevel}% Risk Level
                        </span>
                      </div>
                      <div className="flex items-center gap-2">
                        <div className="w-2 h-2 bg-yellow-400 rounded-full" />
                        <span className="text-gray-300">
                          {chosenCareer?.finalMetrics.growthPotential}% Growth Potential
                        </span>
                      </div>
                    </div>
                  </div>
                </div>
              </Card>
            </motion.div>

            {/* Next Steps */}
            <motion.div
              initial={{ opacity: 0, y: 20 }}
              animate={{ opacity: 1, y: 0 }}
              transition={{ delay: 0.6 }}
              className="max-w-3xl mx-auto"
            >
              <Card className="bg-white/10 backdrop-blur-lg border-white/20 p-6">
                <h3 className="font-semibold text-white mb-4">Next Steps:</h3>
                <div className="space-y-3 text-gray-300">
                  <div className="flex items-start gap-3">
                    <div className="w-6 h-6 bg-purple-500 rounded-full flex items-center justify-center flex-shrink-0 mt-0.5">
                      <span className="text-xs font-bold">1</span>
                    </div>
                    <div>
                      <p className="font-semibold text-white">Research & Learn</p>
                      <p className="text-sm">
                        Deep dive into {chosenCareer?.title} through online courses, certifications, and
                        industry resources
                      </p>
                    </div>
                  </div>
                  <div className="flex items-start gap-3">
                    <div className="w-6 h-6 bg-purple-500 rounded-full flex items-center justify-center flex-shrink-0 mt-0.5">
                      <span className="text-xs font-bold">2</span>
                    </div>
                    <div>
                      <p className="font-semibold text-white">Network</p>
                      <p className="text-sm">
                        Connect with professionals in the field through LinkedIn, meetups, and
                        industry events
                      </p>
                    </div>
                  </div>
                  <div className="flex items-start gap-3">
                    <div className="w-6 h-6 bg-purple-500 rounded-full flex items-center justify-center flex-shrink-0 mt-0.5">
                      <span className="text-xs font-bold">3</span>
                    </div>
                    <div>
                      <p className="font-semibold text-white">Build Skills</p>
                      <p className="text-sm">
                        Start developing the key skills: {chosenCareer?.skills.slice(0, 3).join(", ")}
                      </p>
                    </div>
                  </div>
                  <div className="flex items-start gap-3">
                    <div className="w-6 h-6 bg-purple-500 rounded-full flex items-center justify-center flex-shrink-0 mt-0.5">
                      <span className="text-xs font-bold">4</span>
                    </div>
                    <div>
                      <p className="font-semibold text-white">Get Experience</p>
                      <p className="text-sm">
                        Seek internships, freelance projects, or volunteer work to gain real-world
                        experience
                      </p>
                    </div>
                  </div>
                </div>
              </Card>
            </motion.div>

            {/* Action Buttons */}
            <motion.div
              initial={{ opacity: 0, y: 20 }}
              animate={{ opacity: 1, y: 0 }}
              transition={{ delay: 0.7 }}
              className="flex justify-center gap-4 mt-8"
            >
              <Button
                onClick={() => navigate("/comparison")}
                variant="outline"
                className="bg-white/10 border-white/20 text-white hover:bg-white/20"
              >
                Review Comparison
              </Button>
              <Button
                onClick={() => {
                  sessionStorage.clear();
                  navigate("/");
                }}
                className="bg-gradient-to-r from-blue-600 to-cyan-600 hover:from-blue-700 hover:to-cyan-700"
              >
                <RefreshCw className="mr-2 h-4 w-4" />
                Start Over
              </Button>
              <Button
                onClick={() => navigate("/")}
                className="bg-gradient-to-r from-purple-600 to-pink-600 hover:from-purple-700 hover:to-pink-700"
              >
                <Home className="mr-2 h-4 w-4" />
                Back to Home
              </Button>
            </motion.div>
          </>
        )}
      </div>
    </div>
  );
}
