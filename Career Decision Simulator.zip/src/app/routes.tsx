import { createBrowserRouter } from "react-router";
import { Home } from "./pages/Home";
import { Input } from "./pages/Input";
import { CareerSelection } from "./pages/CareerSelection";
import { Simulation } from "./pages/Simulation";
import { Comparison } from "./pages/Comparison";
import { Decision } from "./pages/Decision";

export const router = createBrowserRouter([
  {
    path: "/",
    Component: Home,
  },
  {
    path: "/input",
    Component: Input,
  },
  {
    path: "/careers",
    Component: CareerSelection,
  },
  {
    path: "/simulation/:careerId",
    Component: Simulation,
  },
  {
    path: "/comparison",
    Component: Comparison,
  },
  {
    path: "/decision",
    Component: Decision,
  },
]);
